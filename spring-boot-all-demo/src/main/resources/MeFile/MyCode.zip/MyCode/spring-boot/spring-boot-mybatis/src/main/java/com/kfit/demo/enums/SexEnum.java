package com.kfit.demo.enums;

/**
 * 性别枚举类.
 * @author Angel -- 守护天使
 * @version v.0.1
 * @date 2017年8月24日
 */
public enum SexEnum {
	MAN, WOMAN
}
