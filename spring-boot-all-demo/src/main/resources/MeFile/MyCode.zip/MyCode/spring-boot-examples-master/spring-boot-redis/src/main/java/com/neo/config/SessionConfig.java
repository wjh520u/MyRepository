package com.neo.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;

import com.fcibook.quick.http.Cookie;
import com.fcibook.quick.http.QuickHttp;

@Configuration
@EnableRedisHttpSession(maxInactiveIntervalInSeconds = 86400*30)
public class SessionConfig {
	
	public static void main	(String[] args) {
		QuickHttp quickHttp = new QuickHttp();
		String text = quickHttp.url("http://192.168.1.187:8089/app/uid").get().text();
		
		Cookie JSESSIONID = quickHttp.body().getCookie().getCookie("JSESSIONID");
		Cookie cookie = quickHttp.body().getCookie().getCookie("SESSION");
		System.out.println(cookie.getValue());
		System.out.println(text);
		System.out.println(1);
		QuickHttp quickHttp2 = new QuickHttp();
		QuickHttp addCookie = quickHttp2.addCookie(cookie.getName(), cookie.getValue());

		addCookie.addCookie(cookie.getName(), cookie.getValue());
		String text2 = addCookie.url("http://192.168.1.187:8089/app/uid").get().text();
		System.out.println(text2);
	}
}